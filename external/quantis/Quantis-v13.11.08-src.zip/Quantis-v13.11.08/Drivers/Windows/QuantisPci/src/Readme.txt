
   .================================================.
===|   Quantis PCI Driver for Microsoft Windows     |==========================
   °================================================°


Table of Contents:
------------------

1. Overview
2. Requirements
3. Files and Directories
4. Compilation

===============================================================================


1. Overview
-----------

   This Readme files details the content of the src directory of the Quantis 
   PCI driver.


2. Requirements
---------------
   
   * Microsoft Windows XP (or newer)
   * Windows Driver Kit (WDK)


3. Files and Directories 
------------------------

   The main directory contains the following files:

   +- common/               --- Include files common for user's programs (GUID,
   |                        --- IOCTL codes and some other goodies)
   |  +- CommonWindows.h
   |  +- Public.h
   |  +- stdint.h   
   +-sys/
   |  +- CommonWindows.c  
   |  +- Driver.c           --- Driver's entry point
   |  +- Makefile           --- Windows build makefile
   |  +- Makefile.inc       --- Windows build makefile
   |  +- Quantis.c          --- Main driver's functions
   |  +- Quantis.h			--- Main driver's functions definitions
   |  +- QuantisOp.c        --- Manipulation functions
   |  +- QuantisOp.h        --- Manipulation functions definitions
   |  +- QuantisReg.h       --- Registers description
   |  +- sources            --- Sources to be compiled (used by the "build")
   |  +- Trace.h            --- Headers to enable WPP/ETW Windows tracing
   |  +- Transfer.c         --- Transfers functions (IOCTL and read) from/to 
   |                        --- the driver to user space
   +-test/
   |  +- QuantisTest.c      --- Test all the Quantis driver's functionalities
   |  +- sources            --- Sources to be compiled (used by the "build")
   +-clean.cmd
   +-dirs                   --- Used by the "build" utility to recursively build


4. Compilation
--------------

  To compile the driver:
  
  1. Open the correct environment in Windows DDK. Note that "checked" means 
     "for debbugging" while "free" means "for production". 
	 
  2. Go to the directory main driver's directory
  
  3. Compile with the command "build -ceZ". 
  
  
  Note: If you want to check if the driver follows the good prommatic rules 
  and standards, use the command "prefast build -ceZ" to compile.
  
  The warnings and the errors are written in files on disk (with extension "wrn" and "err").

                                      

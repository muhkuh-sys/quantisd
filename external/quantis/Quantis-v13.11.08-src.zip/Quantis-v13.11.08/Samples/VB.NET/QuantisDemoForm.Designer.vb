﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class QuantisDemoForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.groupBoxData = New System.Windows.Forms.GroupBox
    Me.GroupBoxInfo = New System.Windows.Forms.GroupBox
    Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown
    Me.ButtonGenerate = New System.Windows.Forms.Button
    Me.Label1 = New System.Windows.Forms.Label
    Me.textBoxBuffer = New System.Windows.Forms.TextBox
    Me.textBoxInfo = New System.Windows.Forms.TextBox
    Me.groupBoxData.SuspendLayout()
    Me.GroupBoxInfo.SuspendLayout()
    CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'groupBoxData
    '
    Me.groupBoxData.Controls.Add(Me.textBoxBuffer)
    Me.groupBoxData.Controls.Add(Me.Label1)
    Me.groupBoxData.Controls.Add(Me.ButtonGenerate)
    Me.groupBoxData.Controls.Add(Me.NumericUpDown1)
    Me.groupBoxData.Location = New System.Drawing.Point(12, 12)
    Me.groupBoxData.Name = "groupBoxData"
    Me.groupBoxData.Size = New System.Drawing.Size(523, 187)
    Me.groupBoxData.TabIndex = 0
    Me.groupBoxData.TabStop = False
    '
    'GroupBoxInfo
    '
    Me.GroupBoxInfo.Controls.Add(Me.textBoxInfo)
    Me.GroupBoxInfo.Location = New System.Drawing.Point(12, 216)
    Me.GroupBoxInfo.Name = "GroupBoxInfo"
    Me.GroupBoxInfo.Size = New System.Drawing.Size(523, 123)
    Me.GroupBoxInfo.TabIndex = 1
    Me.GroupBoxInfo.TabStop = False
    Me.GroupBoxInfo.Text = "Information"
    '
    'NumericUpDown1
    '
    Me.NumericUpDown1.Location = New System.Drawing.Point(165, 160)
    Me.NumericUpDown1.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
    Me.NumericUpDown1.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
    Me.NumericUpDown1.Name = "NumericUpDown1"
    Me.NumericUpDown1.Size = New System.Drawing.Size(61, 20)
    Me.NumericUpDown1.TabIndex = 0
    Me.NumericUpDown1.Value = New Decimal(New Integer() {250, 0, 0, 0})
    '
    'ButtonGenerate
    '
    Me.ButtonGenerate.Location = New System.Drawing.Point(232, 157)
    Me.ButtonGenerate.Name = "ButtonGenerate"
    Me.ButtonGenerate.Size = New System.Drawing.Size(75, 23)
    Me.ButtonGenerate.TabIndex = 1
    Me.ButtonGenerate.Text = "Generate"
    Me.ButtonGenerate.UseVisualStyleBackColor = True
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(15, 162)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(144, 13)
    Me.Label1.TabIndex = 2
    Me.Label1.Text = "Number of bytes to generate:"
    '
    'textBoxBuffer
    '
    Me.textBoxBuffer.Location = New System.Drawing.Point(6, 9)
    Me.textBoxBuffer.Multiline = True
    Me.textBoxBuffer.Name = "textBoxBuffer"
    Me.textBoxBuffer.ReadOnly = True
    Me.textBoxBuffer.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
    Me.textBoxBuffer.Size = New System.Drawing.Size(511, 142)
    Me.textBoxBuffer.TabIndex = 3
    '
    'textBoxInfo
    '
    Me.textBoxInfo.Location = New System.Drawing.Point(6, 19)
    Me.textBoxInfo.Multiline = True
    Me.textBoxInfo.Name = "textBoxInfo"
    Me.textBoxInfo.ReadOnly = True
    Me.textBoxInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
    Me.textBoxInfo.Size = New System.Drawing.Size(511, 98)
    Me.textBoxInfo.TabIndex = 0
    '
    'QuantisDemoForm
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(547, 351)
    Me.Controls.Add(Me.GroupBoxInfo)
    Me.Controls.Add(Me.groupBoxData)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "QuantisDemoForm"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Quantis Demo for VB.NET"
    Me.groupBoxData.ResumeLayout(False)
    Me.groupBoxData.PerformLayout()
    Me.GroupBoxInfo.ResumeLayout(False)
    Me.GroupBoxInfo.PerformLayout()
    CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)

  End Sub
  Friend WithEvents groupBoxData As System.Windows.Forms.GroupBox
  Friend WithEvents textBoxBuffer As System.Windows.Forms.TextBox
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents ButtonGenerate As System.Windows.Forms.Button
  Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
  Friend WithEvents GroupBoxInfo As System.Windows.Forms.GroupBox
  Friend WithEvents textBoxInfo As System.Windows.Forms.TextBox
End Class

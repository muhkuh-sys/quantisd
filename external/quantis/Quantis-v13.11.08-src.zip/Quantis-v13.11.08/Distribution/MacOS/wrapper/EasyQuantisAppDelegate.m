//
//  EasyQuantisAppDelegate.m
//  EasyQuantis
//
//  Created by Administrateur on 04.05.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "EasyQuantisAppDelegate.h"

@implementation EasyQuantisAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end

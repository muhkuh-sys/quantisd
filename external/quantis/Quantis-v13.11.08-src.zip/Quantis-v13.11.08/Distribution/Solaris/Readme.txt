On Solaris the building of a new package is relatively simple and well 
documented at the URL "http://sunfreeware.com".

Here is a quick guide to build IDQ packages:

  1) Create a sub-directory for each package (e.g. /path/to)

  2) Install all files that will be included in the package under the directory
     previously created (/path/to). The tree must be exactly the same as if it 
     installed in the system.
     At this step, the only "critical" decision is the final base directory. 
     Generally "/opt" is the right choice for all the software but driver, that
     must be installed in "/" since the base directory is used in the 
     "postinstall" script and some assumptions are made with the value of the 
     BASEDIR variable (to allow installation in a chrooted environment when 
     installing the system).
  
  3) Create a "pkginfo" and add the description of the package.

  4) Create the "prototype" file:
      a) Add the file describing the package data (pkginfo):
            echo "i pkginfo=./pkginfo" > prototype
      b) Recursively search files that must be added to the package:
            find /path/to/package_files | pkgproto >> prototype
         Where /path/to/package_files is the directory containing all files 
         previously copied.
      c) Edit the prototype file to remove/add (un)needed files and modify 
         (if necessary) the  access rights.
         Note that only files listed in the "prototype" file will be added to 
         the package!

  5) Create the package with the command: 
        pkgmk -r .
  
  6) Convert the package's trees to a flat file:
        pkgtrans -s /var/spool/pkg /usr/local/Quantis/Package/PACKAGE_NAME-VERSION-sol10-sparc
     Note: "/usr/local/Quantis/Package" is the full path of the destination 
     directory of the package.

  7) Test the package by installing it:
        pkgadd -d /usr/local/Quantis/Package/PACKAGE_NAME-VERSION-sol10-sparc"
        
  8) If everything is OK, compress the package with gzip and distribute it.


           
